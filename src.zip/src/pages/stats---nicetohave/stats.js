import React from 'react';
import "./stats.css";

function Stats () {
    return (
        <div>
            
        </div>
    )
}

export default Stats;
